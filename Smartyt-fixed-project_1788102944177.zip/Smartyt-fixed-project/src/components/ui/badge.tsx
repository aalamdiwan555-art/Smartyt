import * as React from "react";
import { cn } from "@/lib/utils";

export function Badge({ className, variant = "default", ...props }: React.HTMLAttributes<HTMLDivElement> & { variant?: "default" | "secondary" | "outline" | "destructive" }) {
  return <div className={cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold capitalize", variant === "default" && "border-transparent bg-primary/12 text-primary", variant === "secondary" && "border-transparent bg-secondary text-secondary-foreground", variant === "outline" && "border-border text-muted-foreground", variant === "destructive" && "border-transparent bg-destructive/12 text-destructive", className)} {...props} />;
}